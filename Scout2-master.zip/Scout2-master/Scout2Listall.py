#!/usr/bin/env python
# -*- coding: utf-8 -*-

from AWSScout2.__listall__ import main
import sys

if __name__ == '__main__':
    sys.exit(main())