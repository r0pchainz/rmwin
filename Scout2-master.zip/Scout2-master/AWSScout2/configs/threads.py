# -*- coding: utf-8 -*-

thread_configs = [
    {'list': 1, 'parse': 1},
    {'list': 1, 'parse': 1},
    {'list': 3, 'parse': 5},
    {'list': 5, 'parse': 10},
    {'list': 10, 'parse': 20},
    {'list': 20, 'parse': 40}
]
